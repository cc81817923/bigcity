/**
 * BP 请求验签中间件
 *
 * BP 调用游戏服务器时，请求头携带 customerId + sign
 * sign = SHA256(customerId={val}&merchantId={val}) 或由 BP 另行约定
 *
 * 文档中接口 1/2/3 的签名参数只有 customerId + sign，
 * 此处实现为：验证 sign = SHA256("customerId=" + customerId + "&merchantId=" + merchantId)
 * 如果 BP 实际给出不同规则，按实际规则替换 buildVerifyStr 即可
 */
const { verify } = require("../utils/sign");
const config = require("../config");

function verifyBP(req, res, next) {
  const { customerId, sign } = req.body || {};

  if (!customerId || !sign) {
    return res.status(400).json({ code: 400, message: "Missing customerId or sign" });
  }

  // 验签参数（按 ASCII 升序）
  const params = {
    customerId,
    merchantId: config.bp.merchantId,
  };

  if (!verify(params, sign)) {
    return res.status(401).json({ code: 401, message: "Invalid signature" });
  }

  req.customerId = customerId;
  next();
}

module.exports = verifyBP;
